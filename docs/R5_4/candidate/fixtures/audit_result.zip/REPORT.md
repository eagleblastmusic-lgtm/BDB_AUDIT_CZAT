Synthetic audit result; unqualified evidence.
