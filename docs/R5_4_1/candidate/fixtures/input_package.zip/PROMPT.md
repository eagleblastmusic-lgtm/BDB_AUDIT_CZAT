Audit only the exact assigned source.
