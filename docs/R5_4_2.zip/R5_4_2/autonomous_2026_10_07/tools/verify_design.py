"""Record fresh draft verification commands, exit codes, inputs and durations.

This deliberately cannot emit a qualification record or promote a gate.
"""

from __future__ import annotations

import importlib.metadata
import subprocess
import sys
import time

from execution import OUT, ROOT, digest, git, preserve, read, write


def main():
    preserve()
    baseline = read(OUT / "PRESERVATION_BASELINE.json")
    production_drift = [name for name, expected in baseline["initial_implementation_files"].items() if digest(ROOT / name) != expected]
    delta_path = OUT / "AUTHORIZED_IMPLEMENTATION_DELTA.json"
    delta = read(delta_path) if delta_path.exists() else {"files": {}}
    assert set(production_drift) == set(delta["files"]), production_drift
    assert all(digest(ROOT / name) == entry["current_raw_digest"] and baseline["initial_implementation_files"][name] == entry["baseline_raw_digest"] for name, entry in delta["files"].items())
    assert all(name not in baseline["initial_implementation_files"] and digest(ROOT / name) == entry["current_raw_digest"]
               for name, entry in delta.get("new_files", {}).items())
    commands = []
    for name in ("execution", "test_semantic_queue_retention", "bootstrap_precedence_design", "bootstrap_registry_integration", "build_context_design", "closure_tiebreak_audit", "source_identity_design", "source_entry_parity", "scope_exclusion_design", "cardinality_audit", "conditional_grammar_audit", "material_path_audit", "exhaustive_reference_audit", "profile_design_audit", "semantic_obligation_queue"):
        commands.append([sys.executable, str(OUT / "tools" / (name + ".py"))])
    commands.extend([[sys.executable, "-m", "ruff", "check", str(OUT / "tools")], ["git", "diff", "--check"]])
    results = []
    for command in commands:
        started = time.monotonic()
        result = subprocess.run(command, cwd=ROOT, capture_output=True, encoding="utf-8", errors="strict")
        entry = {"argv": command, "exit_code": result.returncode, "duration_seconds": round(time.monotonic() - started, 6),
                 "result": "PASS" if result.returncode == 0 else "FAIL", "stdout": result.stdout, "stderr": result.stderr}
        results.append(entry)
        print(entry["result"], " ".join(command), flush=True)
        if result.returncode:
            break
    write("DRAFT_VERIFICATION.json", {
        "source_HEAD": git("rev-parse", "HEAD"), "source_tree": git("rev-parse", "HEAD^{tree}"),
        "python": sys.version, "packages": {name: importlib.metadata.version(name) for name in ("jsonschema", "referencing", "ruff")},
        "commands": results, "production_files_verified_unchanged": len(baseline["initial_implementation_files"]) - len(production_drift),
        "authorized_implementation_delta": delta,
        "production_mismatches": production_drift,
        "preservation_baseline_raw_digest": digest(OUT / "PRESERVATION_BASELINE.json"),
        "tool_inputs": {p.relative_to(ROOT).as_posix(): digest(p) for p in sorted((OUT / "tools").glob("*.py"))},
        "owner_delegated_decision_register_raw_digest": digest(ROOT / "docs/R5_4_2/OWNER_DELEGATED_DECISION_REGISTER.md"),
        "design_outputs": {p.relative_to(OUT).as_posix(): digest(p) for p in sorted((OUT / "design").rglob("*")) if p.is_file()},
        "qualification": False, "candidate_materialized": False, "Q1": "NOT_STARTED", "Q2": "NOT_STARTED", "N5_N11": "NOT_STARTED",
        "NF02": "OPEN", "unexecuted_required_gates": ["semantic predicate parity", "qualified schema fixture execution", "Q1", "Q2", "N5-N11", "required runtime pytest", "mypy", "build", "artifact validator"],
        "repository_status": git("status", "--short")})
    assert all(r["exit_code"] == 0 for r in results), "Draft verification failed; no qualification record emitted"


if __name__ == "__main__":
    main()
