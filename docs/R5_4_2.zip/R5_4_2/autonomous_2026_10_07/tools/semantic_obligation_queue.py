"""Preserve source obligations as explicit, nonqualified semantic work items.

Inventory is deliberately not approval: every source paragraph is retained,
including ones without modal words. Pattern discovery cannot establish parity.
"""

from __future__ import annotations

import copy
import hashlib
import re

from execution import OUT, ROOT, canonical, digest, preserve, read, write


REVIEW_FIELDS = ("review", "review_evidence", "review_notes", "dimension_reviews")


def retain_review(record, previous):
    """Retain a review only against identical, explicitly bound inputs.

    Old unbound reviews remain pending. An invalidated review is retained as
    historical data, never as current closure evidence.
    """
    if not previous:
        return record
    same = previous.get("review_input_digest") == record["review_input_digest"]
    if same:
        for field in REVIEW_FIELDS:
            if field in previous:
                record[field] = copy.deepcopy(previous[field])
        old_paragraphs = {p["paragraph_ordinal"]: p for p in previous["source_paragraphs"]}
        for paragraph in record["source_paragraphs"]:
            old = old_paragraphs.get(paragraph["paragraph_ordinal"], {})
            if old.get("text_sha256") == paragraph["text_sha256"]:
                for field in REVIEW_FIELDS:
                    if field in old:
                        paragraph[field] = copy.deepcopy(old[field])
    elif any(previous.get(f) for f in REVIEW_FIELDS if f != "review") or not previous.get("review", "PENDING").startswith("PENDING"):
        record["invalidated_review"] = {f: copy.deepcopy(previous[f]) for f in REVIEW_FIELDS if f in previous}
        record["invalidated_review"]["review_input_digest"] = previous.get("review_input_digest")
        record["invalidated_review"]["reason"] = "REVIEW_INPUT_CHANGED_OR_UNBOUND"
        record["invalidated_review"]["source_paragraphs"] = copy.deepcopy(previous["source_paragraphs"])
    if "invalidated_review" in previous and "invalidated_review" not in record:
        record["invalidated_review"] = copy.deepcopy(previous["invalidated_review"])
    return record


def review_dependencies():
    # Conservative complete design binding. No dependency is inferred from
    # the review's own claims. Output audits and the queue are not authority.
    names = ["OWN_REFERENCE_RESOLUTIONS.json", "design/VERSION_IMPACT_PLAN.json",
             "design/OWN_FIELD_DOMAINS.json", "design/COMMON_GRAMMARS.json",
             "design/EXTERNAL_PROFILE_CONTRACTS.json", "design/PURPOSE_CONTRACT_GRAMMARS.json",
             "design/PROFILE_REFERENCE_CONTRACTS.json", "design/PAYLOAD_REFERENCE_CONTRACTS.json",
             "design/FULL_PATH_TRANSITION_TABLE.json", "design/COMMAND_EVENT_CONTRACT.md",
             "design/PURPOSE_PREDICATE_CONTRACTS.md", "design/HISTORY_CUT_SEMANTIC_REVIEW.md",
             "design/BOOTSTRAP_PRECEDENCE_SUCCESSOR.json", "design/REGISTRY_BOOTSTRAP_SUCCESSOR_DELTA.json",
             "design/SCOPE_EXCLUSION_SEMANTIC_REVIEW.md", "design/BUILD_INSTALLATION_CONTEXT_REVIEW.md",
             "design/COMMAND_CLOSURE_SEMANTIC_REVIEW.md", "design/SOURCE_IDENTITY_SEMANTIC_REVIEW.md",
             "design/source_instance_readback/READBACK.json", "design/source_instance_readback/ARCHIVE_READBACK.json",
             "design/source_instance_readback/source_manifest_body.json", "design/source_instance_readback/source_head_representation.zip",
             "design/SOURCE_ENTRY_PARITY_CONTROLS.json", "design/source_instance_readback/CURRENT_RUNTIME_RUN.json",
             "design/source_instance_readback/SOURCE_PARSER_READBACK.json"]
    names.extend(p.relative_to(OUT).as_posix() for p in sorted((OUT / "design/source_instance_readback/runtime_runs").glob("*.json")))
    names.extend(p.relative_to(OUT).as_posix() for p in sorted((OUT / "tools").glob("*.py")))
    return {name: digest(OUT / name) for name in names}


def main():
    preserve()
    previous_path = OUT / "design/SEMANTIC_OBLIGATION_QUEUE.json"
    previous_queue = read(previous_path) if previous_path.exists() else {"nodes": []}
    previous = {n["source_key"]: n for n in previous_queue["nodes"]}
    dependencies = review_dependencies()
    graph = read(OUT / "OWN_REFERENCE_RESOLUTIONS.json")
    mapping = read(OUT / "design/VERSION_IMPACT_PLAN.json")["mapping"]
    records = []
    for node in graph["nodes"]:
        source = node.get("source_section") or {}
        paragraphs = [p.strip() for p in re.split(r"\n\s*\n", source.get("complete_section_text", "")) if p.strip()]
        obligations = [{"paragraph_ordinal": i, "text": text, "review": "PENDING",
                        "text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()} for i, text in enumerate(paragraphs)]
        inherited = node.get("qualified_registry_row") or node.get("historical_proposal") or {}
        record = {"source_key": node["key"], "design_key": mapping[node["key"]],
                        "canonical_role": inherited.get("canonical_role"),
                        "producer_authority": inherited.get("producer_authority"),
                        "validation_profile": inherited.get("validation_profile"),
                        "normative_source": {k: source[k] for k in ("file", "section", "raw_digest") if k in source},
                        "source_paragraphs": obligations,
                        "approved_proposal_contract": node.get("historical_proposal"),
                        "actual_material_refs": node["resolved_own_material_refs"],
                        "review": "PENDING_EXACT_SOURCE_BODY_PROFILE_PREDICATE_PARITY",
                        "review_dimensions": ["producer_authority", "reference_targets", "reference_cardinality", "reference_ordering",
                                              "cut_visibility", "campaign_source_scope", "purpose_dispatch", "raw_derivation",
                                              "fsm_eligibility", "uniqueness_retry_conflict", "revision_supersession",
                                              "consumer_applicability", "no_omission", "failure_precedence", "migration"]}
        body_path = OUT / "design/body_grammars" / (record["design_key"].replace("/", "__") + ".json")
        if not body_path.exists():
            from execution import BASE
            body_path = BASE / "candidate/schemas" / (node["key"].replace("/", "__") + ".schema.json")
        inputs = {"record": record, "body_digest": digest(body_path), "dependencies": dependencies,
                  "source_digest": digest(ROOT / source["file"]) if source.get("file") else None,
                  "owner_decisions_digest": digest(ROOT / "docs/R5_4_2/OWNER_DELEGATED_DECISION_REGISTER.md")}
        record["review_input_digest"] = hashlib.sha256(canonical(inputs)).hexdigest()
        records.append(retain_review(record, previous.get(node["key"])))
    write("design/SEMANTIC_OBLIGATION_QUEUE.json", {
        "inventory_digest": hashlib.sha256(canonical(records)).hexdigest(), "nodes": records,
        "pending_nodes": [r["design_key"] for r in records if r["review"] != "SEMANTIC_PARITY_REVIEWED"], "fixed_point_reached": False,
        "claim": "Review queue; source retention is not semantic parity, qualification or canonical execution evidence"})
    print({"review_nodes": len(records), "source_paragraphs_retained": sum(len(r["source_paragraphs"]) for r in records),
           "fixed_point_reached": False})


if __name__ == "__main__":
    main()
