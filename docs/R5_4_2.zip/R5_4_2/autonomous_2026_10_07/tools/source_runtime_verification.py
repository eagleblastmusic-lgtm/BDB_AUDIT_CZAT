"""Run existing source regressions without changing the working repository."""

import sys
import time
import hashlib
from pathlib import Path

from execution import ROOT, digest, git, write


def main():
    sys.path.insert(0, str(ROOT / "src"))
    sys.path.insert(0, str(ROOT / "._nf02_current_audit"))
    import audit_tmp
    import pytest
    from bdb_audit.source import git_resolver

    assert Path(git_resolver.__file__) == ROOT / "src/bdb_audit/source/git_resolver.py"
    head = git("rev-parse", "HEAD")
    targets = sys.argv[1:] or ["tests/stage2/test_ru02_source_identity.py", "tests/stage2/test_source_object_format_regression.py"]
    argv = [*targets, "-q", "--tb=short"]
    test_inputs = {p.relative_to(ROOT).as_posix(): digest(p) for target in targets
                   for p in ([ROOT / target] if (ROOT / target).is_file() else sorted((ROOT / target).rglob("*.py")))}
    implementation_inputs = {p.relative_to(ROOT).as_posix(): digest(p) for p in sorted((ROOT / "src").rglob("*.py"))}
    start = time.monotonic()
    result = pytest.main(argv, plugins=[audit_tmp])
    assert git("rev-parse", "HEAD") == head
    result_name = "design/source_instance_readback/runtime_runs/" + str(time.time_ns()) + ".json"
    record = {
        "argv": argv, "exit_code": int(result), "duration_seconds": time.monotonic() - start,
        "source_HEAD": head, "repository_HEAD_unchanged": True,
        "test_inputs": test_inputs,
        "tool_raw_digest": digest(Path(__file__)),
        "implementation_inputs": implementation_inputs,
        "input_drift": [name for name, before in {**test_inputs, **implementation_inputs}.items() if digest(ROOT / name) != before],
        "environment": "Existing repo-local tmp fixtures; real Git operations in isolated fixture repos",
        "qualification": False, "trusted_profile_selection": "NOT_PROVEN", "NF02": "OPEN"}
    write(result_name, record)
    artifact = ROOT / "docs/R5_4_2/autonomous_2026_10_07" / result_name
    write("design/source_instance_readback/CURRENT_RUNTIME_RUN.json", {
        "file": result_name, "raw_digest": hashlib.sha256(artifact.read_bytes()).hexdigest(),
        "qualification": False, "role": "Diagnostic latest-run locator, never source or acceptance authority"})
    assert not record["input_drift"], "Inputs changed during runtime verification; retained result is not terminal evidence"
    raise SystemExit(result)


if __name__ == "__main__":
    main()
