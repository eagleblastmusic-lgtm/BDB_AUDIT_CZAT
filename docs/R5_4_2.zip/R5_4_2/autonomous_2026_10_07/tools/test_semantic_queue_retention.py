"""Regression controls for preservation and invalidation of review evidence."""

import copy
import unittest

from semantic_obligation_queue import retain_review


class ReviewRetentionTests(unittest.TestCase):
    def setUp(self):
        self.current = {"review_input_digest": "current", "review": "PENDING",
                        "source_paragraphs": [{"paragraph_ordinal": 0, "text_sha256": "text", "review": "PENDING"}]}
        self.previous = copy.deepcopy(self.current)
        self.previous.update(review="SEMANTIC_PARITY_REVIEWED", review_evidence=["exact-evidence"])
        self.previous["source_paragraphs"][0].update(review="REVIEWED", review_notes="exact source")

    def test_unchanged_inputs_retain_review_without_aliasing(self):
        result = retain_review(self.current, self.previous)
        self.assertEqual(result["review"], "SEMANTIC_PARITY_REVIEWED")
        self.assertEqual(result["source_paragraphs"][0]["review"], "REVIEWED")
        result["review_evidence"].append("new")
        self.assertEqual(self.previous["review_evidence"], ["exact-evidence"])

    def test_changed_dependency_invalidates_node_and_paragraph(self):
        self.current["review_input_digest"] = "changed"
        result = retain_review(self.current, self.previous)
        self.assertEqual(result["review"], "PENDING")
        self.assertEqual(result["source_paragraphs"][0]["review"], "PENDING")
        self.assertEqual(result["invalidated_review"]["review_evidence"], ["exact-evidence"])
        self.assertEqual(result["invalidated_review"]["source_paragraphs"][0]["review"], "REVIEWED")

    def test_unbound_old_review_is_not_promoted(self):
        del self.previous["review_input_digest"]
        self.assertEqual(retain_review(self.current, self.previous)["review"], "PENDING")

    def test_changed_paragraph_cannot_inherit_status(self):
        self.current["source_paragraphs"][0]["text_sha256"] = "changed"
        self.assertEqual(retain_review(self.current, self.previous)["source_paragraphs"][0]["review"], "PENDING")

    def test_invalidation_history_survives_next_regeneration(self):
        self.current["review_input_digest"] = "changed"
        result = retain_review(self.current, self.previous)
        regenerated = retain_review(copy.deepcopy(self.current), result)
        self.assertEqual(regenerated["invalidated_review"], result["invalidated_review"])


if __name__ == "__main__":
    unittest.main()
